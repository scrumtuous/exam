## Reporting a security issue

If you find any security issue or vulnerability, please email [ben@straub.cc](mailto:ben@straub.cc) with your report.

Do not open a issue on the `progit/progit2` repository or discuss the vulnerability in public.
