import React, { Component } from 'react';

class Timer extends Component{
    render(){
        return (
            <>
                <button id="timer" class="btn btn-secondary">05:00</button>
            </>
        )
    }
}

export default Timer;